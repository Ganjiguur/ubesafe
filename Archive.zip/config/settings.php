<?php
return array (
  'site-title-mn' => 'Амин хариуцлага',
  'site-title-en' => 'UBeSafe',
  'site-description-mn' => 'Чингис Хаан Банк нь 2001 оны 5 дугаар сарын 18-ны өдөр Монгол Улсад анхны гадаадын 100 хувийн хөрөнгө оруулалттай банк болж үүсгэн байгуулагдсан.',
  'site-description-en' => 'Chinggis Khaan Bank was established on 18th of May 2001, as the first 100 percent foreign invested bank and has been actively involved in large industrial, constructional and investment projects supporting domestic production. ',
  'site-keywords' => 'чингис, хаан, chinggis, khaan, bank, mongolia, чингис хаан банк, chingis khaan bank, mongolian bank, монголын тэргүүлэгч банк, batu digital, бату дижитал',
  'site-social-share' => 'http://ckbank1.ckbank.mn/files/site_meta/808d2b3e190e75668221672de0eb7064.jpg',
  'contact-email' => 'bank@ckbank.mn',
  'contact-phone' => '91177722',
  'facebook' => 'https://www.facebook.com/UBeSAFE/',
  'youtube' => 'https://www.youtube.com/channel/UC9mUnZCn8l8N2ZHIXWpiSOg',
  'contact-address-mn' => 'СБД, 1-р хороо, Чингисийн өргөн чөлөө - 15, Нью Сенчьюри Плаза, 1 ба 5 дугаар давхар',
  'contact-address-en' => 'NCP Floor-1, 5, Sukhbaatar district, Ulaanbaatar 14251, Mongolia',
  'twitter' => 'https://twitter.com/UBeSAFE1?lang=en',
  'facebook-id' => 'chinggiskhaanbank',
  'site-analytics-script' => '<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-61909596-26"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(\'js\', new Date());

  gtag(\'config\', \'UA-61909596-26\');
</script>',
  'donate-link' => 'https://docs.google.com/forms/d/1_uPZndBk0hiT-zS2Dp4MOIDKqUQ1AEProvMAmxf4p6g/edit?usp=sharing',
  'request-link' => 'https://docs.google.com/forms/d/1pkk0GCzZIWKaCuHkkGeI2AbCZjUNocsHjFx9vrpCf3o/edit?usp=sharing',
  'youtube-video-link' => 'https://www.youtube.com/embed/6VHTZEoikA4',
);