<?php

return [
    'number' => '<li><a href="{{url}}">{{text}}</a></li>',
    'current' => '<li class="uk-active"><span>{{text}}</span></li>',
];