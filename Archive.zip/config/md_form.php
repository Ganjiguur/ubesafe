<?php 
return [
    'inputContainer' => '{{content}}',
    'error'=>'<div class="uk-text-danger uk-margin-top">{{content}}</div>',
    'dateWidget' => '{{year}}-{{month}}-{{day}} &nbsp; | &nbsp; {{hour}}:{{minute}} {{second}} {{meridian}}',
    'checkboxWrapper' => '',
    'dateWidget' => '{{year}}{{month}}{{day}}{{hour}}{{minute}}{{second}}{{meridian}}',  
];