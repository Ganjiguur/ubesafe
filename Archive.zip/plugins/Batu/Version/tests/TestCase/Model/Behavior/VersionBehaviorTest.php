<?php
namespace Batu\Version\Test\TestCase\Model\Behavior;

use Batu\Version\Model\Behavior\VersionBehavior;
use Cake\TestSuite\TestCase;

/**
 * Batu\Version\Model\Behavior\VersionBehavior Test Case
 */
class VersionBehaviorTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Batu\Version\Model\Behavior\VersionBehavior
     */
    public $Version;

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $this->Version = new VersionBehavior();
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Version);

        parent::tearDown();
    }

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
