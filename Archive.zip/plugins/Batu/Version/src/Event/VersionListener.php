<?php
namespace Batu\Version\Event;

use Cake\Event\EventListenerInterface;

class VersionListener implements EventListenerInterface {
    
    //Extra data to be passed to the berforeSave event.
    protected $data;
    
    public function __construct($data = [])
    {
        $this->data = $data;
    }

    public function implementedEvents() {
        return array(
            'Model.Version.beforeSave' => 'insertAdditionalData',
        );
    }

    public function insertAdditionalData($event) {
        return $this->data;
    }
}
