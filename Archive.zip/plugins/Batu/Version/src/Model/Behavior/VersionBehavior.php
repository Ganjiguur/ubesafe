<?php
namespace Batu\Version\Model\Behavior;

use ArrayObject;
use Cake\Event\Event;
use Cake\Event\EventManager;
use Cake\ORM\Entity;
use Cake\ORM\Behavior;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\ORM\Query;
use Cake\Collection\Collection;
use Cake\Utility\Hash;
use Cake\Utility\Inflector;
use DateTime;


/**
 * Version behavior
 */
class VersionBehavior extends Behavior
{

    //Table instance
    protected $_table;
    
    /**
     * Default configuration.
     *
     * @var array
     * implementedFinders: no need to touch,
     * versionTable: table name to save changes',
     * versionField: version field to save current version',
     * fields: fields to check and save to version table (always save first field value to identify record),
     * foreignKey: primary key name,
     * referenceName: reference name,
     * onlyDirty: true - zuvhun dirty field uudiig hadgalna, false = buh fields uugiig hadgalna,
     * limit: false - save all version records, if number is given - save total `limit` number of version records,
     * extraGroupFields: group fields,
     * archivedField: archivied field name if model has
     */
    protected $_defaultConfig = [
        'implementedFinders' => ['versions' => 'findVersions'],
        'versionTable' => 'version',
        'versionField' => 'version_id',
        'fields' => null,
        'foreignKey' => 'foreign_key',
        'referenceName' => null,
        'onlyDirty' => false,
        'limit' => false,
        'extraGroupFields' => null,
        'archivedField' => false
    ];
    
    public function initialize(array $config) {
        if ($this->_config['referenceName'] == null) {
            $this->_config['referenceName'] = $this->_referenceName();
        }
        $this->setupFieldAssociations($this->_config['versionTable']);
    }
    
    /**
     * Creates the associations between the bound table and every field passed to
     * this method.
     *
     * Additionally it creates a `version` HasMany association that will be
     * used for fetching all versions for each record in the bound table
     */
    
    public function setupFieldAssociations($table) {
        $options = [
            'table' => $table
        ];
        foreach ($this->_fields() as $field) {
            //$name = $this->_associationName($field);
            $this->versionAssociation($field, $options);
        }
        //$name = $this->_associationName();
        $this->versionAssociation(null, $options);
    }
    
    //Returns association object for all versions or single field version.
    public function versionAssociation($field = null, $options = []) {
        $name = $this->_associationName($field);
        
        if (!$this->_table->associations()->has($name)) {
            $model = $this->_config['referenceName'];
            if ($field) {
                $this->_table->hasOne($name, $options + [
                    'className' => $this->_config['versionTable'],
                    'foreignKey' => $this->_config['foreignKey'],
                    'joinType' => 'LEFT',
                    'conditions' => [
                        $name . '.model' => $model,
                        $name . '.field' => $field,
                    ],
                    'propertyName' => $field . '_version'
                ]);
            } else {
                $this->_table->hasMany($name, $options + [
                    'className' => $this->_config['versionTable'],
                    'foreignKey' => $this->_config['foreignKey'],
                    'strategy' => 'subquery',
                    'conditions' => ["$name.model" => $model],
                    'propertyName' => '__version',
                    'dependent' => false
                ]);
            }
        }
        return $this->_table->association($name);
    }

    public function afterDelete(Event $event, Entity $entity, ArrayObject $options) {
        $action = 'deleted';
        $fields = $this->_fields();
        $values = $entity->extract($fields);
        $model = $this->_config['referenceName'];
        $primaryKey = (array)$this->_table->primaryKey();
        $foreignKey = $this->_extractForeignKey($entity);
        $versionField = $this->_config['versionField'];
        $table = TableRegistry::get($this->_config['versionTable']);
        if (isset($options['versionId'])) {
            $versionId = $options['versionId'];
        } else {
            $preexistent = $table->find()
                ->select(['version_id'])
                ->where([
                    'model' => $model
                ] + $foreignKey)
                ->order(['id desc'])
                ->limit(1)
                ->hydrate(false)
                ->toArray();
            $versionId = Hash::get($preexistent, '0.version_id', 0);
        }
        $created = new DateTime();
        $new = [];
        foreach ($values as $field => $content) {
            if (in_array($field, $primaryKey) || $field == $versionField) {
                continue;
            }
            //Convert array fields to json string
            if (is_array($content)) {
                $content = json_encode($content, JSON_UNESCAPED_UNICODE);
            }
            $data = [
                'version_id' => $versionId,
                'model' => $model,
                'field' => $field,
                'content' => $content,
                'action' => $action,
                'created' => $created,
            ] + $foreignKey;
            $event = new Event('Model.Version.beforeSave', $this, $options);
            $userData = EventManager::instance()->dispatch($event);
            if (isset($userData->result) && is_array($userData->result)) {
                $data = array_merge($data, $userData->result);
            }
            $entityClass = $table->entityClass();
            $new[] = new $entityClass($data, [
                'useSetters' => false,
                'markNew' => true
            ]);
        }
        $table->saveMany($new);
    }
    
    // Modifies the entity before it is saved so that versioned fields are persisted 
    // in the database too.
    public function beforeSave(Event $event, Entity $entity, ArrayObject $options) {
        $association = $this->versionAssociation();
        $name = $association->name();
        $newOptions = [$name => ['validate' => false]];
        $options['associated'] = $newOptions + $options['associated'];
        
        $action = $entity->isNew() === true ? 'created' : 'updated';
        $archivedField = $this->_config['archivedField'];
        
        $allFields = $this->_fields();
        
        if ($action === 'updated' && !empty($archivedField) && $entity->dirty($archivedField)) {
            $action = $entity->get($archivedField) ? 'archived' : 'unarchived';
            $fields = [$archivedField];
        } else {
            $fields = $allFields;
        }
        
        $values = $entity->extract($fields, $this->_config['onlyDirty']);
        
        if(count($allFields) > 0) {
            //Always save first fields as identity
            $first_field = reset($allFields);
            $values[$first_field] = $entity->get($first_field);
        }
        
        $model = $this->_config['referenceName'];
        $primaryKey = (array)$this->_table->primaryKey();
        $foreignKey = $this->_extractForeignKey($entity);
        $versionField = $this->_config['versionField'];
        if (isset($options['versionId'])) {
            $versionId = $options['versionId'];
        } else {
            $table = TableRegistry::get($this->_config['versionTable']);
            $preexistent = $table->find()
                ->select(['version_id'])
                ->where([
                    'model' => $model
                ] + $foreignKey)
                ->order(['id desc'])
                ->limit(1)
                ->hydrate(false)
                ->toArray();
            $versionId = Hash::get($preexistent, '0.version_id', 0) + 1;
        }
        $created = new DateTime();
        $new = [];
        foreach ($values as $field => $content) {
            if (in_array($field, $primaryKey) || $field == $versionField) {
                continue;
            }
            //Convert array fields to json string
            if (is_array($content)) {
                $content = json_encode($content, JSON_UNESCAPED_UNICODE);
            }
            $data = [
                'version_id' => $versionId,
                'model' => $model,
                'field' => $field,
                'content' => $content,
                'action' => $action,
                'created' => $created,
            ] + $foreignKey;
            $event = new Event('Model.Version.beforeSave', $this, $options);
            $userData = EventManager::instance()->dispatch($event);
            if (isset($userData->result) && is_array($userData->result)) {
                $data = array_merge($data, $userData->result);
            }
            $entityClass = $table->entityClass();
            $new[$field] = new $entityClass($data, [
                'useSetters' => false,
                'markNew' => true
            ]);
        }
        $entity->set($association->property(), $new);
        if (!empty($versionField) && in_array($versionField, $this->_table->schema()->columns())) {
            $entity->set($this->_config['versionField'], $versionId);
        }
    }
    
    // Unsets the temporary `__version` property after the entity has been saved
    // Also deletes oldest versions if limit is active and reached.
    public function afterSave(Event $event, Entity $entity) {
        $property = $this->versionAssociation()->property();
        $entity->unsetProperty($property);
        $limit = $this->_config['limit'];
        if (!empty($limit) && is_numeric($limit)) {
            $versionField = $this->_config['versionField'];
            $model = $this->_config['referenceName'];
            $primaryKey = (array)$this->_table->primaryKey();
            $foreignKey = $this->_extractForeignKey($entity);
            $table = TableRegistry::get($this->_config['versionTable']);
            $versionId = null;
                
            if (!empty($versionField) && in_array($versionField, $this->_table->schema()->columns())) {
                $versionId = $entity->get($versionField);
            } else {
                $preexistent = $table->find()
                    ->select(['version_id'])
                    ->where([
                        'model' => $model
                    ] + $foreignKey)
                    ->order(['id desc'])
                    ->limit(1)
                    ->hydrate(false)
                    ->toArray();
                
                $versionId = Hash::get($preexistent, '0.version_id', 0);
            }
            
            if (!empty($versionId) && $versionId > $limit) {
                $table->deleteAll([
                    'model' => $model,
                    'version_id <' =>  $versionId - $limit,
                ] + $foreignKey);
            }
        }
    }
    
    /**
     * Custom finder method used to retrieve all versions for the found records.
     *
     * Versioned values will be found for each entity under the property `_versions`.
     *
     * ### Example:
     *
     * {{{
     * $article = $articles->find('versions')->first();
     * $firstVersion = $article->get('_versions')[1];
     * }}}
     *
     */
    public function findVersions(Query $query, array $options) {
        $association = $this->versionAssociation();
        $name = $association->name();
        return $query
            ->contain([$name => function ($q) use ($name, $options, $query) {
                if (!empty($options['primaryKey'])) {
                    $foreignKey = (array)$this->_config['foreignKey'];
                    $aliasedFK = [];
                    foreach ($foreignKey as $field) {
                        $aliasedFK[] = "$name.$field";
                    }
                    $conditions = array_combine($aliasedFK, (array)$options['primaryKey']);
                    $q->where($conditions);
                }
                if (!empty($options['versionId'])) {
                    $q->where(["$name.version_id IN" => $options['versionId']]);
                }
                $q->where(["$name.field IN" => $this->_fields()]);
                return $q;
            }])
            ->formatResults([$this, 'groupVersions'], $query::PREPEND);
    }
    
    // Modifies the results from a table find in order to merge full version records
    // into each entity under the `_versions` key
    public function groupVersions($results) {
        $property = $this->versionAssociation()->property();
        return $results->map(function ($row) use ($property) {
            $versionField = $this->_config['versionField'];
            $versions = (array)$row->get($property);
            $grouped = new Collection($versions);
            $result = [];
            $extraProperties = [];
            if ($this->_config['extraGroupFields'] !== null) {
                foreach ($grouped->groupBy('version_id') as $versionId => $_versions) {
                    $extraProperties[$versionId] = [];
                    foreach ((array)$this->_config['extraGroupFields'] as $field) {
                        $extraProperties[$versionId][$field] = $_versions[0][$field];
                    }    
                }
            }
            
            foreach ($grouped->combine('field', 'content', 'version_id') as $versionId => $keys) {
                $entityClass = $this->_table->entityClass();
                $version = new $entityClass($keys + [$versionField => $versionId] + $extraProperties[$versionId], [
                    'markNew' => false,
                    'useSetters' => false,
                    'markClean' => true
                ]);
                $result[$versionId] = $version;
            }
            $options = ['setter' => false, 'guard' => false];
            $row->set('_versions', $result, $options);
            unset($row[$property]);
            $row->clean();
            return $row;
        });
    }
    
    //Returns an array of fields to be versioned.
    protected function _fields() {
        $schema = $this->_table->schema();
        $fields = $schema->columns();
        if ($this->_config['fields'] !== null) {
            $fields = array_intersect($fields, (array)$this->_config['fields']);
        }
        return $fields;
    }
    
    // Returns an array with foreignKey value.
    protected function _extractForeignKey($entity) {
        $foreignKey = (array)$this->_config['foreignKey'];
        $primaryKey = (array)$this->_table->primaryKey();
        $pkValue = $entity->extract($primaryKey);
        return array_combine($foreignKey, $pkValue);
    }
    
    //Returns default version association name.
    protected function _associationName($field = null) {
        $alias = Inflector::singularize($this->_table->alias());
        if ($field) {
            $field = Inflector::camelize($field);
        }
        return $alias . $field . 'Version';
    }
    
    //Returns reference name for identifying this model's records in version table.
    protected function _referenceName() {
        $table = $this->_table;
        $name = namespaceSplit(get_class($table));
        $name = substr(end($name), 0, -5);
        if (empty($name)) {
            $name = $table->table() ?: $table->alias();
            $name = Inflector::camelize($name);
        }
        return $name;
    }
}
