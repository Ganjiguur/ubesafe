<?php
namespace Batu\Version\Controller;

use Batu\Version\Controller\AppController;
use Cake\Utility\Inflector;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\TableRegistry;

/**
 * Version Controller
 *
 * @property \Batu\Version\Model\Table\VersionTable $Version
 */
class VersionController extends AppController
{
    public function revisions($table_name, $id)
    {
        if(empty($table_name) || empty($id)) {
            throw new NotFoundException(__('Wrong request!'));
        }
        $table = TableRegistry::get($table_name);
        //TODO: Add feature to customize users table outside of the plugin
        $users = TableRegistry::get("Users");
        $model = $table->get($id);
        $model->versions();
        
        $versions = [];
        $userIds = [];
        
        $maxVersions = 31;
        
        foreach ($model->_versions as $version) {
            if ($version->action == "created" || $version->action == "updated") {
                $versions[] = $version;
                $userIds[] = $version->user_id;
            }
            if(count($versions) == $maxVersions) {
                break;
            }
        }
        
        if (count($versions) < 2) {
            $this->Flash->error(__('No revisions on this data.'));
            return $this->redirect($this->request->referer());
        }
        
        if ($this->request->is('post') && !empty($this->request->data['version'])) {
            $model = $table->patchEntity($model, $this->request->getData(), ['validate' => false]);
            if ($table->save($model)) {
                $this->Flash->success(__('Successfully recovered revision #{0}.', $this->request->data['version']));
                return $this->redirect(['action' => 'revisions', $table_name, $id]);
            } else {
                $this->Flash->error(__("Can't recover this revision."));
            }
        }
        $this->set('model', $model);
        
        $userPhotos = [];
        foreach ($users->find()->where(['id IN' => $userIds])->select(['id', 'photo']) as $user) {
            $userPhotos[$user->id] = $user->photo;
        }
        
        foreach ($versions as $version) {
            $version['user_photo'] = $userPhotos[$version['user_id']];
        } 
        
        $fields = ['title', 'html'];
        if($table->hasField("tabs")) {
            $fields[] = 'tabs';
        }
        $lsufs = [''];
        if($table->hasField("title_en")) {
            $lsufs[] = '_en';
        }

        $this->set(compact('versions', 'model', 'fields', 'lsufs'));
    }

    public function restore($id)
    {
        $version = $this->Version->newEntity();
        if ($this->request->is('post')) {
            $version = $this->Version->patchEntity($version, $this->request->getData());
            if ($this->Version->save($version)) {
                $this->Flash->success(__('The version has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The version could not be saved. Please, try again.'));
        }
        $this->set(compact('version'));
        $this->set('_serialize', ['version']);
    }
}
