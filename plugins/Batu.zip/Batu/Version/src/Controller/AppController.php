<?php
namespace Batu\Version\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
