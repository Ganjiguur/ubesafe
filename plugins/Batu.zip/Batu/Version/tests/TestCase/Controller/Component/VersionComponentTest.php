<?php
namespace Batu\Version\Test\TestCase\Controller\Component;

use Batu\Version\Controller\Component\VersionComponent;
use Cake\Controller\ComponentRegistry;
use Cake\TestSuite\TestCase;

/**
 * Batu\Version\Controller\Component\VersionComponent Test Case
 */
class VersionComponentTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \Batu\Version\Controller\Component\VersionComponent
     */
    public $Version;

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $registry = new ComponentRegistry();
        $this->Version = new VersionComponent($registry);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Version);

        parent::tearDown();
    }

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
